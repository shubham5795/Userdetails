import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'search'
})
export class SearchPipe implements PipeTransform {

  transform(value: any, ...args: any): any {
    console.log(args)
    let filterItems=value.filter(e1 =>{
      if(e1.name.search(args)> -1){
        return true
      }
      else{
        return false
      }
    })
    return filterItems;
  }

}
