import { Injectable } from '@angular/core';
import {User} from '../models/user';
import {Observable} from 'rxjs/Observable';
import {HttpClient} from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  users:User[]=[]
  url:string='https://jsonplaceholder.typicode.com/users'
  constructor( private http: HttpClient) { }

  getAllUsers():Observable<User[]>{
    return this.http.get<User[]>(this.url)
  }
}
